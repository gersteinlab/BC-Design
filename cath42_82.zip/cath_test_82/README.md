# CATH42 Test Set for Refoldability

The table file contains the families and names of the 82 selected proteins. You can find the corresponding PDB files in the pdb_clean folder.
